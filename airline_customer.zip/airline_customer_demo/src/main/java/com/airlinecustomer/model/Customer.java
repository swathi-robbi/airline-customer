package com.airlinecustomer.model;

public class Customer {
    private String name;
    private int frequentFlyerMiles;

    public Customer(String name, int frequentFlyerMiles) {
        this.name = name;
        this.frequentFlyerMiles = frequentFlyerMiles;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getFrequentFlyerMiles() {
        return frequentFlyerMiles;
    }

    public void setFrequentFlyerMiles(int frequentFlyerMiles) {
        this.frequentFlyerMiles = frequentFlyerMiles;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "name='" + name + '\'' +
                ", frequentFlyerMiles=" + frequentFlyerMiles +
                '}';
    }
}
