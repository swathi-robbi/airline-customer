package com.airlinecustomer.model;

import java.util.List;

public class CustomerView {
    private List<Customer> customerList;

    public CustomerView(List<Customer> customerList) {
        this.customerList = customerList;
    }

    public List<Customer> getCustomerList() {
        return customerList;
    }

    public void setCustomerList(List<Customer> customerList) {
        this.customerList = customerList;
    }
}
