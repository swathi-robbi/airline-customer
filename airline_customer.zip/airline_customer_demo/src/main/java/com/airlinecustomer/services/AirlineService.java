package com.airlinecustomer.services;

import com.airlinecustomer.model.Customer;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AirlineService {

    public List<Customer> getCustomerData(){
            return mockCustomerData();
    }

    private List<Customer> mockCustomerData(){
        Customer 	c1	 = new Customer("Customer1", 99991);
        Customer 	c2	 = new Customer("Customer2", 99992);
        Customer 	c3	 = new Customer("Customer3", 99993);
        Customer 	c4	 = new Customer("Customer4", 99994);
        Customer 	c5	 = new Customer("Customer5", 99995);
        Customer 	c6	 = new Customer("Customer6", 99996);
        Customer 	c7	 = new Customer("Customer7", 99997);
        Customer 	c8	 = new Customer("Customer8", 99998);
        Customer 	c9	 = new Customer("Customer9", 99999);
        Customer 	c10	 = new Customer("Customer10", 100000);
        Customer 	c11	 = new Customer("Customer11", 100001);
        Customer 	c12	 = new Customer("Customer12", 100002);
        Customer 	c13	 = new Customer("Customer13", 100003);
        Customer 	c14	 = new Customer("Customer14", 100004);
        Customer 	c15	 = new Customer("Customer15", 100005);
        Customer 	c16	 = new Customer("Customer16", 100006);
        Customer 	c17	 = new Customer("Customer17", 100007);
        Customer 	c18	 = new Customer("Customer18", 100008);
        Customer 	c19	 = new Customer("Customer19", 100009);
        Customer 	c20	 = new Customer("Customer20", 100010);

        List<Customer> customerList = new ArrayList<>();
        customerList.add(c1);
        customerList.add(c2);
        customerList.add(c3);
        customerList.add(c4);
        customerList.add(c5);
        customerList.add(c6);
        customerList.add(c7);
        customerList.add(c8);
        customerList.add(c9);
        customerList.add(c10);
        customerList.add(c11);
        customerList.add(c12);
        customerList.add(c13);
        customerList.add(c14);
        customerList.add(c15);
        customerList.add(c16);
        customerList.add(c17);
        customerList.add(c18);
        customerList.add(c19);
        customerList.add(c20);

        return customerList;
    }
}
