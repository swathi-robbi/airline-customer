package com.airlinecustomer.controller;

import com.airlinecustomer.model.Customer;
import com.airlinecustomer.model.CustomerView;
import com.airlinecustomer.services.AirlineService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
public class CustomerController {


    private final AirlineService airlineService;


    public CustomerController(AirlineService airlineService) {
        this.airlineService = airlineService;
    }
    
    @RequestMapping(value = "api/v1/airline/customer/data/miles", method = { RequestMethod.GET})
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity getCustomerData( @RequestParam(required = false, defaultValue= "0") int flyer_miles_threshold) {
        List<Customer> customerList = airlineService.getCustomerData();
        List<Customer> filteredList;
        //filter list
        if(flyer_miles_threshold != 0 ) {
           filteredList  = customerList
                    .stream()
                    .filter(customer -> customer.getFrequentFlyerMiles() > flyer_miles_threshold)
                    .collect(Collectors.toList());
        }else{
            filteredList = customerList;
        }

        //no exception handling done, always returns data
        return new ResponseEntity(new CustomerView(filteredList), HttpStatus.OK);
    }

}
